"""
Test script for tracker.py module.

Demonstrates:
1. Adding a record
2. Updating status
3. Reloading and printing records
"""

import sys
from pathlib import Path

# Add src directory to path
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))

from tracker import add_application, update_application, load_all, delete_application


def main():
    print("=" * 60)
    print("Testing tracker.py - JSON Application Manager")
    print("=" * 60)
    
    # Test 1: Add a record
    print("\n[Test 1] Adding a record...")
    app1 = add_application(
        person_name="John Smith",
        university_name="Harvard University",
        tone_choice="professional"
    )
    print(f"Created application:")
    print(f"  ID: {app1['id']}")
    print(f"  Person: {app1['person_name']}")
    print(f"  University: {app1['university_name']}")
    print(f"  Status: {app1['status']}")
    print(f"  Created at: {app1['created_at']}")
    print(f"  Tone: {app1['tone_choice']}")
    app1_id = app1["id"]
    
    # Test 2: Add another record
    print("\n[Test 2] Adding another record...")
    app2 = add_application(
        person_name="Jane Doe",
        university_name="MIT",
        tone_choice="formal"
    )
    print(f"Created application:")
    print(f"  ID: {app2['id']}")
    print(f"  Person: {app2['person_name']}")
    print(f"  University: {app2['university_name']}")
    print(f"  Status: {app2['status']}")
    app2_id = app2["id"]
    
    # Test 3: Update status
    print(f"\n[Test 3] Updating status of first record to 'In Progress'...")
    updated = update_application(app1_id, status="In Progress")
    if updated:
        print(f"Updated application:")
        print(f"  ID: {updated['id']}")
        print(f"  Status: {updated['status']}")
    else:
        print("ERROR: Application not found")
    
    # Test 4: Update final email text and mark as sent
    print(f"\n[Test 4] Updating drafts and final email text...")
    updated = update_application(
        app1_id,
        drafts=[
            "Draft 1: Dear Harvard Admissions...",
            "Draft 2: Hello Harvard Team...",
            "Draft 3: Greetings Harvard University..."
        ],
        selected_draft_index=1,
        final_email_text="Dear Harvard Admissions Team...",
        status="Sent",
        sent_at="2026-02-12T14:30:00Z"
    )
    if updated:
        print(f"Updated application:")
        print(f"  Status: {updated['status']}")
        print(f"  Final email text: {updated['final_email_text'][:50]}...")
        print(f"  Sent at: {updated['sent_at']}")
        print(f"  Number of drafts: {len(updated['drafts'])}")
    
    # Test 5: Reload and print all records
    print("\n[Test 5] Reloading and printing all records...")
    all_records = load_all()
    print(f"\nTotal records in database: {len(all_records)}\n")
    for i, record in enumerate(all_records, 1):
        print(f"Record {i}:")
        print(f"  ID: {record['id']}")
        print(f"  Person: {record['person_name']}")
        print(f"  University: {record['university_name']}")
        print(f"  Status: {record['status']}")
        print(f"  Created at: {record['created_at']}")
        print(f"  Sent at: {record['sent_at']}")
        print(f"  Tone: {record['tone_choice']}")
        print(f"  Drafts count: {len(record['drafts'])}")
        print(f"  Final email: {record['final_email_text'][:30] if record['final_email_text'] else 'None'}...")
        print()
    
    # Test 6: Delete a record
    print("[Test 6] Deleting second record...")
    delete_application(app2_id)
    remaining = load_all()
    print(f"Records after deletion: {len(remaining)}")
    
    # Test 7: Reload final state
    print("\n[Test 7] Final state of database:")
    final_records = load_all()
    print(f"Total records: {len(final_records)}")
    for record in final_records:
        print(f"  - {record['person_name']} ({record['university_name']}): {record['status']}")
    
    print("\n" + "=" * 60)
    print("All tests completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    main()
