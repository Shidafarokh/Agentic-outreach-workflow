"""Automated sanity tests for graph generation + HITL-gated send flow."""

from __future__ import annotations

import os
import sys
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

SRC_DIR = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(SRC_DIR))

from graphs import run_graph, run_send_flow
from tracker import add_application, get_application, update_application


def _pass(message: str) -> None:
    print(f"PASS: {message}")


def _fail(message: str) -> None:
    print(f"FAIL: {message}")


def _iso_now() -> str:
    return datetime.utcnow().isoformat() + "Z"


def main() -> None:
    load_dotenv()
    any_fail = False

    app = add_application(person_name="Sanity Tester", university_name="Saint Marys University", tone_choice="Warm")
    app_id = app["id"]

    research_input = "Michael works on reinforcement learning and LLM agents."
    update_application(app_id, research_input=research_input)
    app = get_application(app_id)
    if not app:
        _fail("Could not reload created application.")
        return
    _pass("Created and loaded application.")

    state = run_graph(
        {
            "active_app": app,
            "tone_choice": app.get("tone_choice", "Warm"),
            "research_input": research_input,
            "approved": False,
        }
    )

    drafts = state.get("drafts", [])
    if len(drafts) == 3:
        _pass("Graph produced exactly 3 drafts.")
    else:
        any_fail = True
        _fail(f"Expected 3 drafts, got {len(drafts)}.")

    update_application(
        app_id,
        research_bullets=state.get("research_bullets", []),
        research_keywords=state.get("research_keywords", []),
        drafts=drafts,
        selected_draft_index=0,
        final_email_text=drafts[0] if drafts else "",
        status="Email Generated",
        last_error=state.get("error"),
    )
    _pass("Persisted graph outputs.")

    edited_body = (drafts[0] if drafts else "Fallback body") + "\n\nManual edit."
    update_application(
        app_id,
        final_email_text=edited_body,
        status="Edited",
    )
    send_blocked = run_send_flow(active_app=app, email_body=edited_body, approved=False)
    if (not send_blocked.get("success")) and "Not approved" in (send_blocked.get("error") or ""):
        _pass("Send blocked when approved=False.")
    else:
        any_fail = True
        _fail("Send was not properly blocked for approved=False.")

    update_application(app_id, status="Approved")
    latest = get_application(app_id) or app
    send_result = run_send_flow(
        active_app=latest,
        email_body=latest.get("final_email_text", edited_body),
        approved=True,
    )

    if send_result.get("success"):
        update_application(app_id, status="Sent", sent_at=_iso_now(), last_error=None)
        _pass("Approved send succeeded; status set to Sent.")
    else:
        update_application(app_id, status="Failed", last_error=send_result.get("error"))
        msg = send_result.get("error") or ""
        if os.getenv("GMAIL_USER") and os.getenv("GMAIL_APP_PASSWORD"):
            any_fail = True
            _fail(f"Approved send failed despite credentials: {msg}")
        else:
            _pass("Approved send failed gracefully due to missing/invalid Gmail config; status set to Failed.")

    final_app = get_application(app_id)
    if not final_app:
        any_fail = True
        _fail("Could not load final app state.")
    else:
        final_status = final_app.get("status")
        if final_status in {"Sent", "Failed"}:
            _pass(f"Final status is {final_status}.")
        else:
            any_fail = True
            _fail(f"Unexpected final status: {final_status}")

    if any_fail:
        print("\nRESULT: SOME TESTS FAILED")
        raise SystemExit(1)
    print("\nRESULT: ALL TESTS PASSED")


if __name__ == "__main__":
    main()
