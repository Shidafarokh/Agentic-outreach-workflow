"""Email Project - Streamlit Dashboard with LangGraph Multi-Agent System"""
