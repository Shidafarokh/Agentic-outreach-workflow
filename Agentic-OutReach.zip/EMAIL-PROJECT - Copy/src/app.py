"""Streamlit dashboard for application tracking and HITL email generation."""

from __future__ import annotations

import sys
import os
import re
from datetime import datetime
from pathlib import Path

import streamlit as st
import requests

sys.path.insert(0, str(Path(__file__).parent))

from env_config import load_env_vars
from graphs import run_graph, run_send_flow
from profile_store import load_profile, save_profile
from tracker import (
    add_application,
    delete_application,
    get_application,
    load_all,
    update_application,
)

load_env_vars()

STATUS_OPTIONS = [
    "Draft",
    "Research Ready",
    "Email Generated",
    "Edited",
    "Approved",
    "Sent",
    "Failed",
]
TONE_OPTIONS = ["Academic", "Warm"]
USER_NAME = "Shida Farokh"
GOAL_OPTIONS = [
    "Research Assistantship",
    "TA Position",
    "PhD Lab Interest",
    "Coffee Chat",
    "Collaboration",
]
INTEREST_OPTIONS = [
    "Mental Health /",
    "LLM Agents & Tool Use",
    "Retrieval-Augmented Generation (RAG)",
    "Information Retrieval & Search",
    "NLP (Text Mining, Transformers)",
    "Prompt Engineering & Evaluation",
    "Model Monitoring & Robustness",
    "Machine Learning (Supervised/Unsupervised)",
    "Explainable AI (XAI)",
    "Responsible AI, Fairness & Bias",
    "Causal Inference",
    "Experiment Design & A/B Testing",
    "Recommender Systems",
    "Time Series Forecasting",
    "Optimization & Operations Research",
    "Decision Analytics & Simulation",
    "Risk Analytics / Monte Carlo",
    "Financial Analytics",
    "Product Analytics",
    "Customer Analytics / Segmentation",
    "Supply Chain Analytics",
    "Healthcare Analytics",
    "Public Policy / Social Impact Analytics",
    "Data Visualization & Storytelling",
    "Data Engineering & Pipelines",
    "MLOps / Deployment",
    "Computer Vision",
    "Graph Analytics / Network Science",
    "Privacy & Security (AI)",
    "Other (Custom)",
]
SKILL_OPTIONS = [
    "Python",
    "SQL",
    "R",
    "Power BI",
    "Excel",
    "Tableau",
    "Statistics",
    "Optimization",
    "Git",
    "Other",
]
PROJECT_OPTIONS = [
    "LLM Agent Email Automation",
    "Research Paper Recommender",
    "Time Series Forecasting Dashboard",
    "Healthcare Analytics Pipeline",
    "Optimization-based Scheduling Tool",
    "Causal Inference Study",
]


def _inject_ui_styles() -> None:
    st.markdown(
        """
<style>
:root {
  --primary-color: #a88fff;
}
section.main > div.block-container {
  padding-top: 1.4rem;
  padding-bottom: 2rem;
}
html, body, [class*="css"] {
  font-weight: 400;
  color: #251f35;
}
h1, h2, h3 {
  letter-spacing: 0.15px;
  color: #2f2352;
}
.card {
  border: 1px solid #cdb8ff;
  border-radius: 12px;
  padding: 18px;
  margin: 14px 0;
  background: #fff;
}
.kpi {
  border: 1px solid #d8c6ff;
  border-radius: 10px;
  padding: 12px 14px;
  background: #f6f0ff;
}
.kpi-label {
  font-size: 0.82rem;
  color: #5b4a86;
}
.kpi-value {
  font-size: 1.2rem;
  font-weight: 700;
  color: #3e2f67;
}
.section-header {
  padding: 10px 12px;
  border-left: 5px solid #c8b6ff;
  background: #faf7ff;
  border-radius: 10px;
  margin-top: 10px;
  margin-bottom: 10px;
  font-weight: 700;
}
.status-pill, .badge-sent, .badge-draft, .badge-failed {
  display: inline-block;
  padding: 0.2rem 0.55rem;
  border-radius: 999px;
  font-weight: 700;
  font-size: 0.82rem;
  margin-right: 0.35rem;
}
.badge-sent { background: #e5f2ff; color: #1e4f8f; border: 1px solid #b7d7ff; }
.badge-draft { background: #fff7d6; color: #7a6200; border: 1px solid #f1df93; }
.badge-failed { background: #ffe7ef; color: #8a2a4f; border: 1px solid #f0b7cd; }
.pill-research { background: #e6f7ff; color: #0b5c8e; border: 1px solid #87d2ff; }
.pill-generated { background: #efeaff; color: #4b2aa8; border: 1px solid #c4b3ff; }
.pill-edited { background: #efeaff; color: #4b2aa8; border: 1px solid #c4b3ff; }
.pill-approved { background: #d9f7e8; color: #116b41; border: 1px solid #7cd8af; }
.approval-no { color: #b00020; font-weight: 700; }
.approval-yes { color: #157347; font-weight: 700; }
div[data-testid="stButton"] > button[kind="primary"] {
  background: #bda7ff;
  border: 1px solid #a88fff;
  color: #271a49;
}
div[data-testid="stButton"] > button[kind="primary"]:hover {
  background: #b39bff;
  border: 1px solid #9f84ff;
  color: #1f143d;
}
.muted {
  color: #74688f;
}
div[data-testid="stExpander"] {
  border: 1px solid #d8c6ff !important;
  border-radius: 12px !important;
  background: #fcf9ff !important;
}
div[data-testid="stExpander"] details > summary {
  background: #f6f0ff !important;
  border-radius: 12px !important;
  border: 1px solid #d8c6ff !important;
}
[data-testid="stTabs"] [data-baseweb="tab-list"] {
  gap: 0.35rem !important;
}
[data-testid="stTabs"] [data-baseweb="tab"] {
  color: #4e3a87 !important;
  border: 1px solid #cdb8ff !important;
  background: #f5efff !important;
  border-radius: 12px 12px 0 0 !important;
  font-size: 1.2rem !important;
  font-weight: 800 !important;
  padding: 0.55rem 0.95rem !important;
  min-height: 2.8rem !important;
}
[data-testid="stTabs"] [data-baseweb="tab"][aria-selected="true"] {
  color: #2f2159 !important;
  background: #e7dbff !important;
  border: 2px solid #bda7ff !important;
  border-bottom: 3px solid #8f6bff !important;
  font-weight: 900 !important;
  font-size: 1.36rem !important;
  transform: translateY(-1px) !important;
}
input[type="checkbox"], input[type="radio"] {
  accent-color: #a88fff;
}
[data-testid="stTabs"] [data-baseweb="tab"]:hover {
  background: #eee5ff !important;
  color: #3b2a73 !important;
}
div[data-testid="stButton"] > button:disabled {
  background: #efe6ff !important;
  border: 1px solid #cfbfff !important;
  color: #3e2c74 !important;
  opacity: 1 !important;
}
.stMultiSelect div[data-baseweb="tag"],
div[data-baseweb="select"] div[data-baseweb="tag"],
div[data-baseweb="tag"] {
  background: #8f6bff !important;
  border: 1px solid #7b56ea !important;
}
.stMultiSelect div[data-baseweb="tag"] *,
div[data-baseweb="select"] div[data-baseweb="tag"] *,
div[data-baseweb="tag"] * {
  color: #ffffff !important;
}
.stMultiSelect [data-baseweb="tag"] {
  background-color: #8f6bff !important;
}
.stMultiSelect [data-baseweb="tag"] span {
  color: #ffffff !important;
}
.stMultiSelect [data-baseweb="tag"] svg,
.stMultiSelect [data-baseweb="tag"] path {
  fill: #ffffff !important;
  color: #ffffff !important;
}
.stMultiSelect svg,
div[data-baseweb="select"] svg {
  color: #6a57a8 !important;
  fill: #6a57a8 !important;
}
.stMultiSelect [role="option"][aria-selected="true"],
div[data-baseweb="popover"] [role="option"][aria-selected="true"] {
  background: #f3ecff !important;
  color: #3e2c74 !important;
}
[data-testid="stTextInput"] input,
[data-testid="stTextArea"] textarea,
[data-testid="stSelectbox"] div[data-baseweb="select"] > div,
[data-testid="stMultiSelect"] div[data-baseweb="select"] > div {
  border: 1px solid #cdb8ff !important;
  box-shadow: none !important;
}
[data-testid="stCheckbox"] div[role="checkbox"] {
  border: 1px solid #a88fff !important;
}
[data-testid="stCheckbox"] div[role="checkbox"][aria-checked="true"] {
  background: #bda7ff !important;
  border: 1px solid #a88fff !important;
}
[data-testid="stCheckbox"] div[role="checkbox"][aria-checked="true"] svg,
[data-testid="stCheckbox"] div[role="checkbox"][aria-checked="true"] path {
  fill: #ffffff !important;
  color: #ffffff !important;
}
[data-testid="stRadio"] div[role="radio"][aria-checked="true"] {
  border-color: #a88fff !important;
}
[data-testid="stRadio"] div[role="radio"][aria-checked="true"]::before {
  background: #a88fff !important;
}
</style>
""",
        unsafe_allow_html=True,
    )


def _status_css_class(status: str) -> str:
    mapping = {
        "Draft": "badge-draft",
        "Research Ready": "pill-research",
        "Email Generated": "pill-generated",
        "Edited": "pill-edited",
        "Approved": "pill-approved",
        "Sent": "badge-sent",
        "Failed": "badge-failed",
    }
    return mapping.get(status, "badge-draft")


def _status_badge(status: str) -> str:
    css = _status_css_class(status)
    return f"<span class='status-pill {css}'>{status}</span>"


def _iso_now() -> str:
    return datetime.utcnow().isoformat() + "Z"


def _format_dt(value: str | None) -> str:
    if not value:
        return "-"
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return value


def _normalize_app(app: dict) -> dict:
    app.setdefault("status", "Draft")
    app.setdefault("sent_at", None)
    app.setdefault("tone_choice", "Warm")
    app.setdefault("drafts", [])
    app.setdefault("selected_draft_index", 0)
    app.setdefault("final_email_text", "")
    app.setdefault("last_error", None)
    app.setdefault("research_input", "")
    app.setdefault("research_bullets", [])
    app.setdefault("research_keywords", [])
    app.setdefault("professor_name", "")
    app.setdefault("scholar_profile_url", "")
    app.setdefault("recipient_email", "")
    app.setdefault("smu_profile_url", "")
    app.setdefault("email_source", "")
    return app


def _app_label(app: dict) -> str:
    return f"{app.get('person_name', 'Unknown')} - {app.get('university_name', 'Unknown')} - {app.get('id', '')[:8]}"


def _tone_label(value: str) -> str:
    if value == "Warm":
        return "Warm and Friendly"
    return value


def _enforce_target_name_in_draft(draft_text: str, target_name: str, previous_names: list[str] | None = None) -> str:
    text = (draft_text or "").strip()
    target = (target_name or "").strip()
    if not text or not target:
        return text

    # Force greeting to match the current selected professor/target.
    text = re.sub(
        r"^(Dear\s+Professor\s+).*$",
        rf"\1{target},",
        text,
        flags=re.IGNORECASE | re.MULTILINE,
    )

    # Replace stale professor names from previous runs if they appear in body text.
    if previous_names:
        for old_name in previous_names:
            old = (old_name or "").strip()
            if not old:
                continue
            if old.lower() == target.lower():
                continue
            text = re.sub(rf"\b{re.escape(old)}\b", target, text, flags=re.IGNORECASE)
    return text


def _fetch_scholar_context(scholar_profile_url: str) -> tuple[str, list[str]]:
    """
    Lightweight Scholar page extraction (best-effort, non-fatal).
    Returns (research_input_text, professor_keywords).
    """
    url = (scholar_profile_url or "").strip()
    if not url:
        return "", []

    try:
        resp = requests.get(
            url,
            timeout=12,
            headers={"User-Agent": "Mozilla/5.0 (EmailProjectBot/1.0)"},
        )
        if resp.status_code != 200:
            return f"Scholar URL provided but fetch failed: HTTP {resp.status_code}", []

        html = resp.text
        titles = re.findall(r'class="gsc_a_at"[^>]*>(.*?)</a>', html, flags=re.IGNORECASE | re.DOTALL)
        titles = [re.sub(r"\s+", " ", t).strip() for t in titles if t.strip()]
        top_titles = titles[:8]

        text_blob = " ".join(top_titles)
        raw_tokens = re.findall(r"[A-Za-z][A-Za-z\-]{3,}", text_blob.lower())
        stop = {
            "with", "from", "using", "based", "data", "analysis", "model", "models",
            "approach", "study", "learning", "towards", "through", "method", "methods",
        }
        keywords = []
        seen = set()
        for tok in raw_tokens:
            if tok in stop or tok in seen:
                continue
            seen.add(tok)
            keywords.append(tok)
            if len(keywords) >= 15:
                break

        research_text = ""
        if top_titles:
            research_text = "Scholar publications:\n" + "\n".join(f"- {t}" for t in top_titles)
        else:
            research_text = f"Scholar profile provided: {url}"

        return research_text, keywords
    except Exception as exc:
        return f"Scholar URL provided but fetch failed: {exc}", []


def _ensure_demo_dal_records() -> None:
    demo_names = ["Rita Orji", "Anup Basu", "Stan Matwin"]
    existing = load_all()
    existing_keys = {
        (a.get("person_name", "").strip().lower(), a.get("university_name", "").strip().lower(), a.get("status", ""))
        for a in existing
    }
    for name in demo_names:
        key = (name.strip().lower(), "dalhousie university", "Sent")
        if key in existing_keys:
            continue
        rec = add_application(person_name=name, university_name="Dalhousie University", tone_choice="Academic")
        update_application(rec["id"], status="Sent", sent_at=_iso_now(), last_error=None)


def _render_dashboard_tab() -> None:
    st.header("Application Tracker")
    _ensure_demo_dal_records()
    all_apps = [_normalize_app(a) for a in load_all()]

    sent_count = sum(1 for a in all_apps if a.get("status") == "Sent")
    draft_count = sum(1 for a in all_apps if a.get("status") == "Draft")
    failed_count = sum(1 for a in all_apps if a.get("status") == "Failed")
    total_count = draft_count + sent_count + failed_count
    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(
            f"<div class='kpi'><div class='kpi-label'>Total</div><div class='kpi-value'>{total_count}</div></div>",
            unsafe_allow_html=True,
        )
    with k2:
        st.markdown(
            f"<div class='kpi'><div class='kpi-label'>Sent</div><div class='kpi-value'>{sent_count}</div></div>",
            unsafe_allow_html=True,
        )
    with k3:
        st.markdown(
            f"<div class='kpi'><div class='kpi-label'>Draft</div><div class='kpi-value'>{draft_count}</div></div>",
            unsafe_allow_html=True,
        )
    with k4:
        st.markdown(
            f"<div class='kpi'><div class='kpi-label'>Failed</div><div class='kpi-value'>{failed_count}</div></div>",
            unsafe_allow_html=True,
        )

    col_f1, col_f2 = st.columns(2)
    with col_f1:
        status_filter = st.selectbox("Filter by Status", ["All"] + STATUS_OPTIONS, key="filter_status")
    with col_f2:
        unique_universities = sorted({a.get("university_name", "") for a in all_apps if a.get("university_name")})
        university_filter = st.selectbox(
            "Filter by University",
            ["All"] + unique_universities,
            key="filter_university",
        )

    filtered = [
        a
        for a in all_apps
        if not (
            (a.get("person_name", "").strip().lower() in {"test user", "sanity tester"})
            and ("smu" in a.get("university_name", "").strip().lower() or "saint mary" in a.get("university_name", "").strip().lower())
        )
    ]
    if status_filter != "All":
        filtered = [a for a in filtered if a.get("status") == status_filter]
    if university_filter != "All":
        filtered = [a for a in filtered if a.get("university_name") == university_filter]

    table_rows = [
        {
            "person_name": a.get("person_name", ""),
            "university_name": a.get("university_name", ""),
            "status": a.get("status", "Draft"),
        }
        for a in filtered
    ]
    header = st.columns([2.5, 2.5, 1.4])
    header[0].markdown("**Professor**")
    header[1].markdown("**University**")
    header[2].markdown("**Status**")
    st.divider()
    if not table_rows:
        st.write("No records.")
    else:
        for row in table_rows:
            cols = st.columns([2.5, 2.5, 1.4])
            cols[0].write(row["person_name"])
            cols[1].write(row["university_name"])
            cols[2].markdown(_status_badge(row["status"]), unsafe_allow_html=True)

    st.divider()

    st.subheader("Create New Application")
    c1, c2, c3 = st.columns(3)
    with c1:
        new_person = st.text_input("Professor Name", value=USER_NAME, key="new_person_name")
    with c2:
        new_university = st.text_input("University Name", key="new_university_name")
    with c3:
        new_tone = st.selectbox("Tone", TONE_OPTIONS, key="new_tone", format_func=_tone_label)

    if st.button("+ New Application", use_container_width=True):
        if not new_person.strip() or not new_university.strip():
            st.error("Person and university are required.")
        else:
            created = add_application(
                person_name=new_person.strip(),
                university_name=new_university.strip(),
                tone_choice=new_tone,
            )
            st.session_state.active_app_id = created["id"]
            st.success("Application created.")
            st.rerun()

    st.divider()
    st.subheader("Select Active Application")
    if not all_apps:
        st.info("No applications yet.")
        return

    app_ids = [a["id"] for a in all_apps]
    labels = [_app_label(a) for a in all_apps]
    current_id = st.session_state.get("active_app_id")
    if current_id not in app_ids:
        current_idx = 0
        st.session_state.active_app_id = app_ids[0]
    else:
        current_idx = app_ids.index(current_id)

    selected_label = st.selectbox("Active application", labels, index=current_idx, key="active_selector")
    st.session_state.active_app_id = app_ids[labels.index(selected_label)]
    active_app = _normalize_app(get_application(st.session_state.active_app_id) or {})

    if not active_app:
        st.warning("Active application not found.")
        return

    st.markdown("### Active Application")
    st.markdown(
        (
            f"<div>Professor: {active_app.get('person_name', '-')}</div>"
            f"<div>University: {active_app.get('university_name', '-')}</div>"
            f"<div>Status: {_status_badge(active_app.get('status', 'Draft'))}</div>"
            f"<div>Sent At: {_format_dt(active_app.get('sent_at'))}</div>"
            f"<div>Drafts: {len(active_app.get('drafts', []))}</div>"
        ),
        unsafe_allow_html=True,
    )

    st.divider()
    confirm_delete = st.checkbox("I understand this cannot be undone")
    if st.button("Delete Application", use_container_width=False, type="secondary"):
        if not confirm_delete:
            st.error("Check confirmation first.")
        else:
            delete_application(active_app["id"])
            st.session_state.active_app_id = None
            st.success("Application deleted.")
            st.rerun()


def _render_generator_tab() -> None:
    st.header("Email Generator")

    active_id = st.session_state.get("active_app_id")
    if not active_id:
        st.info("Create/select an application in Dashboard first.")
        return

    active_app = get_application(active_id)
    if not active_app:
        st.error("Active application not found.")
        return
    active_app = _normalize_app(active_app)

    drafts_for_step = active_app.get("drafts", [])
    approved_now = active_app.get("status") == "Approved"
    step = 1
    if (active_app.get("person_name") or "").strip() or (active_app.get("scholar_profile_url") or "").strip():
        step = 2
    if drafts_for_step:
        step = 3
    if approved_now:
        step = 4

    with st.expander("Step 1 - Target", expanded=False):
        target_name = st.text_input(
            "Professor / Target Name",
            value=active_app.get("person_name", ""),
            key=f"target_name_{active_id}",
        )
        scholar_profile_url = st.text_input(
            "Google Scholar Profile URL",
            value=active_app.get("scholar_profile_url", ""),
            key=f"scholar_url_{active_id}",
        )
        use_scholar = st.checkbox("Use Scholar Data", value=True, key=f"use_scholar_{active_id}")
        use_profile = st.checkbox("Use My Profile Data", value=True, key=f"use_profile_{active_id}")
        recipient_email_input = st.text_input(
            "Recipient Email",
            value=active_app.get("recipient_email", ""),
            key=f"recipient_email_{active_id}",
        )
        with st.expander("Scholar Snapshot (optional)", expanded=False):
            existing_keywords = active_app.get("research_keywords", []) or []
            if existing_keywords:
                st.write(f"Top keywords: {', '.join(existing_keywords[:8])}")
            else:
                st.markdown("<span class='muted'>No keywords yet.</span>", unsafe_allow_html=True)

            publications = []
            research_input_text = active_app.get("research_input", "") or ""
            for line in research_input_text.splitlines():
                line = line.strip()
                if line.startswith("- "):
                    publications.append(line[2:])
            if publications:
                st.write("Top publications:")
                for item in publications[:3]:
                    st.write(f"- {item}")
            else:
                st.markdown("<span class='muted'>No publications parsed yet.</span>", unsafe_allow_html=True)

    with st.expander("Step 2 - Generate", expanded=False):
        selected_tone = st.selectbox(
            "Preferred Tone",
            TONE_OPTIONS,
            index=TONE_OPTIONS.index(active_app.get("tone_choice", "Warm")) if active_app.get("tone_choice", "Warm") in TONE_OPTIONS else 0,
            key=f"tone_choice_{active_id}",
            format_func=_tone_label,
        )
        generate_clicked = st.button("Generate Drafts", type="primary", use_container_width=True)

    if generate_clicked:
        if use_profile:
            profile_data = load_profile()
        else:
            profile_data = {
                "full_name": USER_NAME,
                "program": "MBAN",
                "goal": "Research Assistantship",
                "interests": [],
                "skills": [],
                "projects": [],
                "linkedin_url": "https://www.linkedin.com/in/shida-farokh-677a39382/",
            }

        scholar_context = ""
        scholar_keywords: list[str] = []
        if use_scholar and scholar_profile_url.strip():
            scholar_context, scholar_keywords = _fetch_scholar_context(scholar_profile_url.strip())

        update_application(
            active_id,
            person_name=target_name.strip() or active_app.get("person_name", ""),
            professor_name=target_name.strip(),
            scholar_profile_url=scholar_profile_url.strip(),
            recipient_email=recipient_email_input.strip(),
            research_input=scholar_context,
            tone_choice=selected_tone,
        )
        latest_app = _normalize_app(get_application(active_id) or active_app)

        try:
            warm_state = run_graph(
                {
                    "active_app": latest_app,
                    "tone_choice": "Warm",
                    "research_input": scholar_context,
                    "my_profile": profile_data,
                    "approved": False,
                }
            )
            academic_state = run_graph(
                {
                    "active_app": latest_app,
                    "tone_choice": "Academic",
                    "research_input": scholar_context,
                    "my_profile": profile_data,
                    "approved": False,
                }
            )
            drafts = [
                (warm_state.get("drafts") or [""])[0],
                (academic_state.get("drafts") or [""])[0],
            ]
            previous_names = [
                active_app.get("person_name", ""),
                active_app.get("professor_name", ""),
            ]
            drafts = [_enforce_target_name_in_draft(d, target_name, previous_names) for d in drafts]
            professor_keywords = warm_state.get("research_keywords", []) or scholar_keywords
            interests = set([x.lower() for x in (profile_data.get("interests", []) if isinstance(profile_data, dict) else [])])
            common_keywords = [k for k in professor_keywords if isinstance(k, str) and k.lower() in interests]

            st.session_state[f"evidence_{active_id}"] = {
                "scholar_profile_url": scholar_profile_url.strip(),
                "professor_keywords": professor_keywords,
                "common_keywords": common_keywords,
            }
            st.session_state[f"debug_{active_id}"] = {
                "graph_trace": warm_state.get("graph_trace", []),
                "error": warm_state.get("error"),
            }

            update_application(
                active_id,
                person_name=target_name.strip() or active_app.get("person_name", ""),
                professor_name=target_name.strip(),
                scholar_profile_url=scholar_profile_url.strip(),
                research_input=scholar_context,
                research_bullets=warm_state.get("research_bullets", []),
                research_keywords=professor_keywords,
                drafts=drafts[:2],
                selected_draft_index=0,
                final_email_text=drafts[0] if drafts else "",
                status="Email Generated",
                last_error=warm_state.get("error"),
                tone_choice=selected_tone,
            )
            # Clear editor widget state so previous professor text is not reused.
            for k in list(st.session_state.keys()):
                if k.startswith(f"draft_edit_{active_id}_"):
                    del st.session_state[k]
            st.session_state.pop(f"draft_picker_{active_id}", None)
            st.info("Draft generation complete.")
            st.rerun()
        except Exception as exc:
            update_application(active_id, status="Failed", last_error=str(exc))
            st.error(f"Generation failed: {exc}")

    refreshed = _normalize_app(get_application(active_id) or active_app)
    drafts = refreshed.get("drafts", [])

    if drafts:
        with st.expander("Step 3 - Review & Edit", expanded=False):
            tone_labels = ["Draft 1 - Warm", "Draft 2 - Academic"]
            selected_idx = refreshed.get("selected_draft_index", 0)
            if selected_idx >= len(drafts):
                selected_idx = 0

            selected_label = st.selectbox(
                "Select draft",
                tone_labels[: len(drafts)],
                index=selected_idx,
                key=f"draft_picker_{active_id}",
            )
            chosen_idx = tone_labels.index(selected_label)
            base_text = drafts[chosen_idx]
            if (
                refreshed.get("final_email_text")
                and refreshed.get("selected_draft_index", 0) == chosen_idx
            ):
                base_text = refreshed.get("final_email_text")

            edited_text = st.text_area(
                "Email body",
                value=base_text,
                height=260,
                key=f"draft_edit_{active_id}_{chosen_idx}",
            )
            if st.button("Save Edit", use_container_width=True):
                update_application(
                    active_id,
                    selected_draft_index=chosen_idx,
                    final_email_text=edited_text,
                    status="Edited",
                )
                st.success("Edit saved.")
                st.rerun()

        with st.expander("Step 4 - Approve & Send", expanded=False):
            approval = st.radio("Approve to Send?", ["No", "Yes"], index=0, horizontal=True, key=f"approve_send_{active_id}")
            can_send = approval == "Yes"
            if approval == "Yes":
                update_application(active_id, status="Approved")

            target_email = (recipient_email_input or refreshed.get("recipient_email") or "").strip()
            if st.button("Send", disabled=not can_send, type="primary", use_container_width=True):
                latest = _normalize_app(get_application(active_id) or refreshed)
                update_application(active_id, recipient_email=target_email)
                if not target_email:
                    update_application(active_id, status="Failed", last_error="Recipient email is required.")
                    st.error("Recipient email is required.")
                    return
                email_body = edited_text if edited_text.strip() else (latest.get("final_email_text") or drafts[chosen_idx])
                send_result = run_send_flow(
                    active_app=latest,
                    email_body=email_body,
                    approved=can_send,
                    to_email_override=target_email,
                )
                if send_result["success"]:
                    update_application(
                        active_id,
                        final_email_text=email_body,
                        status="Sent",
                        sent_at=_iso_now(),
                        last_error=None,
                    )
                    st.session_state["send_count"] = int(st.session_state.get("send_count", 0)) + 1
                    st.success(f"Email sent to {send_result['to_email']}.")
                else:
                    update_application(active_id, status="Failed", last_error=send_result["error"])
                    st.error(send_result["error"])
                refreshed = _normalize_app(get_application(active_id) or refreshed)
                st.caption(f"Current status: {refreshed.get('status', '-')}, sent_at: {_format_dt(refreshed.get('sent_at'))}")

    evidence = st.session_state.get(f"evidence_{active_id}", {})
    with st.expander("Evidence (Scholar)", expanded=False):
        st.write(f"Scholar URL: {evidence.get('scholar_profile_url', refreshed.get('scholar_profile_url', '-')) or '-'}")
        st.write(f"Professor keywords: {', '.join(evidence.get('professor_keywords', refreshed.get('research_keywords', []))) or '-'}")

def _render_about_tab() -> None:
    st.header("About / ReadMe")
    st.markdown("<div class='section-header'>Technical Documentation</div>", unsafe_allow_html=True)
    st.markdown("## **PhD Outreach Assistant, Technical Overview**")
    st.markdown("### **Project Purpose**")
    st.markdown(
        "- Generates personalized professor outreach emails with controlled automation.\n"
        "- Reduces repetitive drafting while preserving contextual accuracy.\n"
        "- Enforces explicit human approval before send.\n"
        "- Drafting is automated; accountability stays with the user."
    )

    st.markdown("### **Architecture Overview**")
    st.markdown(
        "- **Streamlit:** interface layer for profile input, context entry, draft review, approval, and send.\n"
        "- **LangGraph:** stateful orchestration with explicit transitions and predictable execution.\n"
        "- **LangChain `create_agent`:** standardized agent construction for research + draft generation.\n"
        "- **JSON persistence:** transparent local state, zero operational overhead, deliberate tradeoff vs DB."
    )

    st.markdown("### **Core Graph Design**")
    st.code(
        "node_prepare\n"
        "   |\n"
        "   v\n"
        "node_research_subgraph\n"
        "   |----> node_research_clean\n"
        "   |----> node_research_keywords\n"
        "   v\n"
        "node_generate_drafts\n"
        "   |\n"
        "   v\n"
        "node_hitl\n"
        "   |\n"
        "   v\n"
        "node_end",
        language="text",
    )
    st.markdown(
        "- `node_prepare`: validates and initializes state.\n"
        "- `node_research_subgraph`: isolates preprocessing and extraction logic.\n"
        "- `node_generate_drafts`: calls drafting agent; fallback templates on failure.\n"
        "- `node_hitl`: approval gate; no send without explicit user decision.\n"
        "- `node_end`: final state consolidation."
    )

    st.markdown("### **End-to-End Flow**")
    st.code(
        "User Input (Profile + Professor + Scholar URL)\n"
        "        |\n"
        "        v\n"
        "Streamlit UI\n"
        "        |\n"
        "        v\n"
        "LangGraph Main Flow\n"
        "        |\n"
        "        v\n"
        "Draft Generation (LLM or fallback)\n"
        "        |\n"
        "        v\n"
        "HITL Approval Gate (Yes/No)\n"
        "        |\n"
        "   +----+----+\n"
        "   |         |\n"
        "  No        Yes\n"
        "   |         |\n"
        "   v         v\n"
        "Status: Edited    SMTP Send\n"
        "                  |\n"
        "                  v\n"
        "          Sent / Failed + JSON update",
        language="text",
    )

    st.markdown("### **State & Data Flow**")
    st.markdown(
        "- Student profile\n"
        "- Scholar context\n"
        "- Cleaned research bullets\n"
        "- Extracted keywords\n"
        "- Generated drafts\n"
        "- Selected draft index\n"
        "- Approval flag\n"
        "- Send result and final status"
    )
    st.markdown("### **Robustness & Failure Handling**")
    st.markdown(
        "- Missing API key: fallback drafts/research output, no crash.\n"
        "- LLM failure: deterministic fallback logic, workflow continues.\n"
        "- SMTP failure: status -> `Failed`, error persisted in `last_error`.\n"
        "- System fails safely and keeps application state consistent."
    )
    st.markdown("### **Personalization Logic**")
    st.markdown(
        "- Extracts professor signals (keywords/publication cues).\n"
        "- Computes overlap with student interests/skills/projects.\n"
        "- Produces tone variants for controlled messaging.\n"
        "- Requires HITL approval before any send action."
    )
    st.markdown("### **Design Tradeoffs**")
    st.markdown(
        "- No database: simpler ops, lower scalability.\n"
        "- Scholar scraping fragility: upstream page changes can break extraction.\n"
        "- LLM non-determinism: output variation mitigated by review.\n"
        "- Approval step adds friction by design for safety."
    )


def _render_profile_tab() -> None:
    st.header("Profile")
    profile = load_profile()
    full_name = st.text_input("Full Name", value=profile.get("full_name", USER_NAME))
    program = st.text_input("Program", value=profile.get("program", "MBAN"))
    university = st.text_input("University", value=profile.get("university", "Saint Mary's University"))

    goal = st.selectbox(
        "Goal",
        GOAL_OPTIONS,
        index=GOAL_OPTIONS.index(profile.get("goal", GOAL_OPTIONS[0]))
        if profile.get("goal", GOAL_OPTIONS[0]) in GOAL_OPTIONS
        else 0,
    )
    interests_default = [x for x in profile.get("interests", []) if x in INTEREST_OPTIONS]
    skills_default = [x for x in profile.get("skills", []) if x in SKILL_OPTIONS]
    projects_default = [x for x in profile.get("projects", []) if x in PROJECT_OPTIONS]

    interests = st.multiselect("Interests", INTEREST_OPTIONS, default=interests_default)
    skills = st.multiselect("Skills", SKILL_OPTIONS, default=skills_default)
    projects = st.multiselect("Projects", PROJECT_OPTIONS, default=projects_default)
    custom_project = st.text_input("Custom Project (Optional)", value=profile.get("custom_project", ""))

    availability_options = ["This week", "Next week", "Flexible"]
    availability = st.selectbox(
        "Availability",
        availability_options,
        index=availability_options.index(profile.get("availability", "Flexible"))
        if profile.get("availability", "Flexible") in availability_options
        else 2,
    )
    contact_email = st.text_input("Contact Email", value=profile.get("contact_email", ""))
    linkedin_url = st.text_input("LinkedIn URL (Optional)", value=profile.get("linkedin_url", ""))

    if st.button("Save Profile", type="secondary", use_container_width=True):
        final_projects = list(projects)
        if custom_project.strip():
            final_projects.append(custom_project.strip())
        profile_data = {
            "full_name": full_name.strip(),
            "program": program.strip() or "MBAN",
            "university": university.strip() or "Saint Mary's University",
            "goal": goal,
            "interests": interests,
            "skills": skills,
            "projects": final_projects,
            "custom_project": custom_project.strip(),
            "availability": availability,
            "contact_email": contact_email.strip(),
            "linkedin_url": linkedin_url.strip(),
        }
        save_profile(profile_data)
        st.success("Profile saved")

def main() -> None:
    st.set_page_config(page_title="PHD EMAIL GENERATOR", layout="wide")
    _inject_ui_styles()
    st.title("PhD Outreach Assistant")
    st.caption("Personalized email drafts from Scholar + your profile (HITL approval)")

    if "active_app_id" not in st.session_state:
        st.session_state.active_app_id = None
    if "send_count" not in st.session_state:
        st.session_state.send_count = 0

    tab1, tab2, tab3, tab4 = st.tabs(["Profile", "Email Generator", "Dashboard", "About / ReadMe"])
    with tab1:
        _render_profile_tab()
    with tab2:
        _render_generator_tab()
    with tab3:
        _render_dashboard_tab()
    with tab4:
        _render_about_tab()


if __name__ == "__main__":
    main()


