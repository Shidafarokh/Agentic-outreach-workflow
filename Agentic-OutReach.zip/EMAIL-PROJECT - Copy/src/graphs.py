"""
LangGraph workflow for email generation.

Main flow:
node_prepare -> node_research_subgraph -> node_generate_drafts -> node_hitl -> node_end
"""

from __future__ import annotations

from typing import TypedDict
import importlib.util
import json
import os
import re
from pathlib import Path

from langgraph.graph import END, StateGraph

from env_config import load_env_vars
from mailer import send_email_smtp


_agents_spec = importlib.util.spec_from_file_location(
    "email_project_agents", Path(__file__).with_name("agents.py")
)
_agents_module = importlib.util.module_from_spec(_agents_spec)
_agents_spec.loader.exec_module(_agents_module)
build_email_agents = _agents_module.build_email_agents

_research_agents_spec = importlib.util.spec_from_file_location(
    "email_project_research_agents", Path(__file__).with_name("research_agents.py")
)
_research_agents_module = importlib.util.module_from_spec(_research_agents_spec)
_research_agents_spec.loader.exec_module(_research_agents_module)
build_research_agents = _research_agents_module.build_research_agents


class EmailGenerationState(TypedDict):
    active_app: dict
    tone_choice: str
    drafts: list[str]
    selected_draft: int
    edited_email: str
    approved: bool
    error: str | None
    graph_trace: list[str]
    research_input: str
    research_bullets: list[str]
    research_keywords: list[str]
    my_profile: dict


def _append_error(state: EmailGenerationState, message: str) -> None:
    existing = state.get("error")
    if existing:
        state["error"] = f"{existing} | {message}"
    else:
        state["error"] = message


def _extract_list_from_agent_result(result: dict) -> list[str] | None:
    messages = result.get("messages", [])
    if not messages:
        return None

    content = messages[-1].content
    if not isinstance(content, str):
        return None

    try:
        parsed = json.loads(content)
        if isinstance(parsed, list):
            return [str(item).strip() for item in parsed if str(item).strip()]
    except json.JSONDecodeError:
        match = re.search(r"\[[\s\S]*\]", content)
        if match:
            parsed = json.loads(match.group(0))
            if isinstance(parsed, list):
                return [str(item).strip() for item in parsed if str(item).strip()]
    return None


def _naive_bullets(text: str) -> list[str]:
    if not text or not text.strip():
        return [
            "No research details provided yet.",
            "Ask the applicant for research interests and projects.",
            "Keep the message aligned to program strengths.",
            "Highlight motivation and fit with faculty.",
            "Use concrete examples where possible.",
        ]

    chunks = [
        c.strip(" .,-;\n\t")
        for c in re.split(r"[.\n;]+", text)
        if c and c.strip(" .,-;\n\t")
    ]
    bullets = [chunk[:140] for chunk in chunks[:8]]
    filler = [
        "Connect interests to specific labs or faculty.",
        "Show readiness for rigorous research work.",
        "Emphasize measurable outcomes from past projects.",
        "Highlight fit with the target department.",
        "Show curiosity and long-term research direction.",
    ]
    idx = 0
    while len(bullets) < 5:
        bullets.append(filler[idx % len(filler)])
        idx += 1
    return bullets[:8]


def _naive_keywords(text: str) -> list[str]:
    if not text or not text.strip():
        return [
            "research",
            "university fit",
            "faculty alignment",
            "motivation",
            "academic goals",
            "projects",
            "impact",
            "collaboration",
        ]

    tokens = re.findall(r"[A-Za-z][A-Za-z0-9\-+]{2,}", text.lower())
    stop = {
        "the",
        "and",
        "for",
        "with",
        "that",
        "this",
        "from",
        "into",
        "about",
        "your",
        "their",
        "have",
        "has",
        "were",
        "been",
        "being",
        "will",
        "would",
        "should",
        "could",
        "can",
        "our",
        "his",
        "her",
        "its",
        "they",
        "them",
        "you",
        "are",
        "was",
        "not",
        "but",
    }

    seen = set()
    keywords: list[str] = []
    for token in tokens:
        if token in stop or token in seen:
            continue
        seen.add(token)
        keywords.append(token)
        if len(keywords) >= 15:
            break

    if len(keywords) < 8:
        keywords.extend(
            [
                "research",
                "innovation",
                "analysis",
                "methodology",
                "publication",
                "experiments",
                "results",
                "impact",
            ][: 8 - len(keywords)]
        )

    return keywords[:15]


def node_prepare(state: EmailGenerationState) -> EmailGenerationState:
    state["graph_trace"].append("node_prepare")

    if not state.get("active_app"):
        state["error"] = "No active application loaded."
        return state

    if "drafts" not in state or not isinstance(state["drafts"], list):
        state["drafts"] = []
    if "research_input" not in state or state["research_input"] is None:
        state["research_input"] = ""
    if "research_bullets" not in state or not isinstance(state["research_bullets"], list):
        state["research_bullets"] = []
    if "research_keywords" not in state or not isinstance(state["research_keywords"], list):
        state["research_keywords"] = []

    return state


def node_research_clean(state: EmailGenerationState) -> EmailGenerationState:
    state["graph_trace"].append("node_research_clean")
    research_input = state.get("research_input", "")

    try:
        load_env_vars()
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY is missing")

        research_agents = build_research_agents()
        cleaner = research_agents["research_cleaner_agent"]
        prompt = (
            "Turn the input into 5-8 concise bullets for downstream email drafting.\n"
            f"Input:\n{research_input}\n\n"
            "Return only a JSON array of bullet strings."
        )
        result = cleaner.invoke({"messages": [{"role": "user", "content": prompt}]})
        bullets = _extract_list_from_agent_result(result)
        if not bullets:
            raise ValueError("Cleaner response could not be parsed as a list")
        state["research_bullets"] = bullets[:8]
    except Exception as exc:
        state["research_bullets"] = _naive_bullets(research_input)
        _append_error(state, f"Research cleaner fallback used: {exc}")

    return state


def node_research_keywords(state: EmailGenerationState) -> EmailGenerationState:
    state["graph_trace"].append("node_research_keywords")
    research_input = state.get("research_input", "")
    bullets_text = "\n".join(state.get("research_bullets", []))

    try:
        load_env_vars()
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY is missing")

        research_agents = build_research_agents()
        keyword_agent = research_agents["keyword_agent"]
        prompt = (
            "Extract 8-15 concise keywords/topics from this research context.\n"
            f"Research input:\n{research_input}\n\n"
            f"Clean bullets:\n{bullets_text}\n\n"
            "Return only a JSON array of keywords."
        )
        result = keyword_agent.invoke({"messages": [{"role": "user", "content": prompt}]})
        keywords = _extract_list_from_agent_result(result)
        if not keywords:
            raise ValueError("Keyword response could not be parsed as a list")
        state["research_keywords"] = keywords[:15]
    except Exception as exc:
        combined = f"{research_input}\n{bullets_text}".strip()
        state["research_keywords"] = _naive_keywords(combined)
        _append_error(state, f"Keyword fallback used: {exc}")

    return state


def build_research_subgraph():
    research_builder = StateGraph(EmailGenerationState)
    research_builder.add_node("node_research_clean", node_research_clean)
    research_builder.add_node("node_research_keywords", node_research_keywords)
    research_builder.add_edge("node_research_clean", "node_research_keywords")
    research_builder.add_edge("node_research_keywords", END)
    research_builder.set_entry_point("node_research_clean")
    return research_builder.compile()


research_subgraph = build_research_subgraph()


def node_research_subgraph(state: EmailGenerationState) -> EmailGenerationState:
    state["graph_trace"].append("node_research_subgraph")
    return research_subgraph.invoke(state)


REFLECTION_LINE = (
    "I am naturally pulled toward research that asks not only \"does this work?\" "
    "but \"does this make sense?\" and \"can it scale thoughtfully?\" "
    "That lens is something I have been trying to cultivate in my own growth, "
    "and your work reflects that mindset clearly."
)

HUMAN_LINE = (
    "Curiosity has always been my starting point, not just about problems, "
    "but about the people working on them. I care about research spaces where "
    "ideas can shift, adapt, and improve through open discussion, and that "
    "human element is something I genuinely value."
)
FIXED_LINKEDIN_URL = "https://www.linkedin.com/in/shida-farokh-677a39382/"


def _fallback_drafts(
    student_name: str,
    professor_name: str,
    student_program: str,
    university_name: str,
    tone: str,
    professor_ref: str,
    profile_ref: str,
    goal: str,
) -> list[str]:
    if tone == "Warm":
        return [
            f"Dear Professor {professor_name},\n\nI recently came across your research on {professor_ref}, and I appreciated how your work brings structure and practical relevance together. As part of my development, I have been working with {profile_ref} and exploring ways to align this with my goal in {goal}.\n\n{HUMAN_LINE}\n\nI would value the opportunity to briefly connect and learn whether there may be space for me to contribute.\n\nWarm regards,\n{student_name}\n{student_program}, {university_name}",
            f"Dear Professor {professor_name},\n\nI am writing because your work on {professor_ref} strongly resonated with me. I have been building experience through {profile_ref}, and I see clear overlap with the research direction I hope to pursue.\n\n{HUMAN_LINE}\n\nIf you are open to it, I would appreciate a short conversation about possible opportunities to contribute.\n\nBest regards,\n{student_name}\n{student_program}, {university_name}",
            f"Dear Professor {professor_name},\n\nMy name is {student_name}, and I am reaching out due to your work on {professor_ref}. I have been developing my background in {profile_ref}, and I am seeking to contribute in a {goal} capacity where this alignment is meaningful.\n\n{HUMAN_LINE}\n\nWould you be open to a brief meeting to discuss fit?\n\nSincerely,\n{student_name}\n{student_program}, {university_name}",
        ]
    if tone == "Academic":
        return [
            f"Dear Professor {professor_name},\n\nI am writing to express my interest in your research direction on {professor_ref}. My academic preparation in {profile_ref} aligns with this line of work and motivates my application-oriented research focus.\n\n{REFLECTION_LINE}\n\nI would welcome the opportunity to discuss whether my background may support your ongoing initiatives in a {goal} capacity.\n\nSincerely,\n{student_name}\n{student_program}, {university_name}",
            f"Dear Professor {professor_name},\n\nI am reaching out regarding your work on {professor_ref}. My current training and project work in {profile_ref} has led me to questions that align with this area, especially around rigorous and interpretable methods.\n\n{REFLECTION_LINE}\n\nIf appropriate, I would appreciate the chance to discuss potential fit.\n\nRespectfully,\n{student_name}\n{student_program}, {university_name}",
            f"Dear Professor {professor_name},\n\nI am contacting you to express interest in your research focus on {professor_ref}. My background in {profile_ref} and my objective in {goal} align closely with this direction.\n\n{REFLECTION_LINE}\n\nPlease let me know if you would be open to a brief conversation.\n\nRespectfully submitted,\n{student_name}\n{student_program}, {university_name}",
        ]
    return [
        f"Dear Professor {professor_name},\n\nYour research direction on {professor_ref} aligns with the kind of scalable, evaluation-driven systems I want to help build. My hands-on work in {profile_ref} gives me a practical base to contribute.\n\n{REFLECTION_LINE}\n\nIf useful, I would appreciate discussing potential collaboration in a {goal} role.\n\nBest regards,\n{student_name}\n{student_program}, {university_name}",
        f"Dear Professor {professor_name},\n\nI am reaching out because your work on {professor_ref} reflects the type of high-impact, structured research I am preparing for. I can contribute through my applied background in {profile_ref}.\n\n{REFLECTION_LINE}\n\nI would value a short discussion on potential collaboration.\n\nRegards,\n{student_name}\n{student_program}, {university_name}",
        f"Dear Professor {professor_name},\n\nI see strong alignment between your work on {professor_ref} and my development path through {profile_ref}. I am looking for opportunities where I can contribute meaningfully in a {goal} capacity.\n\n{REFLECTION_LINE}\n\nPlease let me know if you are open to a brief conversation.\n\nYours truly,\n{student_name}\n{student_program}, {university_name}",
    ]


def _extract_profile_refs(my_profile: dict) -> tuple[str, str]:
    goal = my_profile.get("goal") or "Research Assistantship"
    skills = my_profile.get("skills") or []
    projects = my_profile.get("projects") or []
    interests = my_profile.get("interests") or []
    profile_ref = None
    for source in (skills, projects, interests):
        if source:
            profile_ref = source[0]
            break
    if not profile_ref:
        profile_ref = goal
    return goal, str(profile_ref)


def _ensure_constraints_in_draft(
    draft: str,
    professor_ref: str,
    profile_ref: str,
    goal: str,
) -> str:
    out = draft
    out = re.sub(r"(?im)^\s*subject\s*:\s*.*\n?", "", out).strip()
    if not re.search(r"(?i)^dear\s+professor", out):
        out = f"Dear Professor,\n\n{out}"
    if professor_ref and professor_ref.lower() not in out.lower():
        out += f"\n\nI am particularly interested in your work on {professor_ref}."
    profile_terms = [profile_ref, goal]
    if not any(term and term.lower() in out.lower() for term in profile_terms):
        out += f"\n\nThis also aligns with my goal in {goal} and my background in {profile_ref}."
    if FIXED_LINKEDIN_URL.lower() not in out.lower():
        out += f"\n\nLinkedIn: {FIXED_LINKEDIN_URL}"
    return out


def node_generate_drafts(state: EmailGenerationState) -> EmailGenerationState:
    state["graph_trace"].append("node_generate_drafts")
    if not state.get("active_app"):
        return state

    app = state["active_app"]
    my_profile = state.get("my_profile") or {}
    student_name = my_profile.get("full_name") or "Shida Farokh"
    student_program = my_profile.get("program") or "Student"
    professor_name = app.get("professor_name") or app.get("person_name", "Professor")
    university_name = app.get("university_name", "University")
    tone = state.get("tone_choice", "Warm")
    research_bullets = state.get("research_bullets", [])
    research_keywords = state.get("research_keywords", [])
    goal, profile_ref = _extract_profile_refs(my_profile)
    professor_ref = research_keywords[0] if research_keywords else (
        research_bullets[0] if research_bullets else "your recent publications"
    )
    fallback_drafts = _fallback_drafts(
        student_name,
        professor_name,
        student_program,
        university_name,
        tone,
        professor_ref,
        profile_ref,
        goal,
    )

    try:
        load_env_vars()
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY is missing")

        email_agents = build_email_agents()
        draft_agent = email_agents["draft_generator"]
        bullet_block = "\n".join(f"- {b}" for b in research_bullets) if research_bullets else "- None"
        keyword_block = ", ".join(research_keywords) if research_keywords else "None"
        profile_block = json.dumps(my_profile, ensure_ascii=True, indent=2)
        tone_template = ""
        if tone == "Warm":
            tone_template = (
                "Warm template style:\n"
                "Subject line\n"
                "Greeting\n"
                "Reference professor work\n"
                "Alignment + skills/projects\n"
                "Short CTA\n"
                "Warm closing\n"
                f"Optional personal line to include naturally: {HUMAN_LINE}"
            )
        elif tone == "Academic":
            tone_template = (
                "Academic template style:\n"
                "Subject line\n"
                "Greeting\n"
                "Research-specific reference\n"
                "Structured alignment + methods\n"
                "Formal CTA for RA/TA discussion\n"
                "Formal closing\n"
                f"Optional personal line to include naturally: {REFLECTION_LINE}"
            )
        else:
            tone_template = (
                "Strategic template style:\n"
                "Subject line\n"
                "Greeting\n"
                "Impact/value framing from professor work\n"
                "Clear value you bring (skills/projects)\n"
                "Direct CTA for collaboration\n"
                "Concise closing\n"
                f"Optional personal line to include naturally: {REFLECTION_LINE}"
            )
        prompt = (
            "Generate exactly 3 university application email drafts.\n"
            f"Student name: {student_name}\n"
            f"Student program: {student_program}\n"
            f"Professor name: {professor_name}\n"
            f"University name: {university_name}\n"
            f"Tone choice: {tone}\n\n"
            f"Research bullets:\n{bullet_block}\n\n"
            f"Research keywords: {keyword_block}\n\n"
            f"Applicant profile JSON:\n{profile_block}\n\n"
            f"{tone_template}\n\n"
            "Requirements for each draft:\n"
            "1) Must mention at least one professor keyword/publication topic from the provided research context.\n"
            "2) Must mention at least one applicant-specific item from profile goal/skills/projects/interests.\n"
            "3) Signature MUST use Student name, never Professor name.\n"
            "4) Do NOT say 'apply for MBAN' or any program application phrasing unless goal explicitly requests degree admission.\n"
            "5) Do NOT include any subject line in the output body.\n"
            "6) Greeting should reference the provided Professor name.\n"
            "Output format: JSON array with exactly 3 string items."
        )
        result = draft_agent.invoke({"messages": [{"role": "user", "content": prompt}]})
        generated_drafts = _extract_list_from_agent_result(result)
        if not generated_drafts or len(generated_drafts) < 3:
            raise ValueError("Agent response did not contain exactly 3 drafts")
        state["drafts"] = [
            _ensure_constraints_in_draft(d, professor_ref, profile_ref, goal)
            for d in generated_drafts[:3]
        ]
    except Exception as exc:
        state["drafts"] = [
            _ensure_constraints_in_draft(d, professor_ref, profile_ref, goal)
            for d in fallback_drafts[:3]
        ]
        _append_error(state, f"LLM draft generation fallback used: {exc}")

    state["selected_draft"] = 0
    return state


def node_hitl(state: EmailGenerationState) -> EmailGenerationState:
    state["graph_trace"].append("node_hitl")
    if state.get("approved") and state.get("drafts"):
        state["edited_email"] = state["drafts"][state.get("selected_draft", 0)]
    return state


def node_end(state: EmailGenerationState) -> EmailGenerationState:
    state["graph_trace"].append("node_end")
    return state


def build_graph():
    graph_builder = StateGraph(EmailGenerationState)
    graph_builder.add_node("node_prepare", node_prepare)
    graph_builder.add_node("node_research_subgraph", node_research_subgraph)
    graph_builder.add_node("node_generate_drafts", node_generate_drafts)
    graph_builder.add_node("node_hitl", node_hitl)
    graph_builder.add_node("node_end", node_end)
    graph_builder.add_edge("node_prepare", "node_research_subgraph")
    graph_builder.add_edge("node_research_subgraph", "node_generate_drafts")
    graph_builder.add_conditional_edges("node_generate_drafts", lambda _state: "node_hitl")
    graph_builder.add_edge("node_hitl", "node_end")
    graph_builder.add_edge("node_end", END)
    graph_builder.set_entry_point("node_prepare")
    return graph_builder.compile()


graph = build_graph()


def run_graph(input_state: dict) -> dict:
    if "graph_trace" not in input_state:
        input_state["graph_trace"] = []
    if "drafts" not in input_state:
        input_state["drafts"] = []
    if "selected_draft" not in input_state:
        input_state["selected_draft"] = 0
    if "edited_email" not in input_state:
        input_state["edited_email"] = ""
    if "approved" not in input_state:
        input_state["approved"] = False
    if "error" not in input_state:
        input_state["error"] = None
    if "research_input" not in input_state:
        input_state["research_input"] = ""
    if "research_bullets" not in input_state:
        input_state["research_bullets"] = []
    if "research_keywords" not in input_state:
        input_state["research_keywords"] = []
    if "my_profile" not in input_state:
        input_state["my_profile"] = {}
    return graph.invoke(input_state)


def run_send_flow(
    active_app: dict,
    email_body: str,
    approved: bool,
    to_email_override: str | None = None,
) -> dict:
    """
    Send flow with strict HITL gate and restricted destination.

    Returns:
      {
        "success": bool,
        "error": str|None,
        "to_email": str,
        "subject": str
      }
    """
    load_env_vars()
    to_email = (to_email_override or "").strip() or os.getenv("TEST_RECEIVER_EMAIL", "Yilin.Huang@smu.ca")
    subject = (
        f"University Application Email - "
        f"{active_app.get('person_name', 'Applicant')} -> {active_app.get('university_name', 'University')}"
    )

    if not approved:
        return {
            "success": False,
            "error": "Not approved. Email sending is blocked by HITL gate.",
            "to_email": to_email,
            "subject": subject,
        }

    success, error_message = send_email_smtp(
        to_email=to_email,
        subject=subject,
        body=email_body,
    )
    return {
        "success": success,
        "error": error_message,
        "to_email": to_email,
        "subject": subject,
    }
