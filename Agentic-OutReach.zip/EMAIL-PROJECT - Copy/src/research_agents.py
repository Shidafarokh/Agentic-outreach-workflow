"""LangChain research agents for research preprocessing."""

import os
from langchain.agents import create_agent

from env_config import load_env_vars


def build_research_agents():
    """Build and return create_agent-based research agents."""
    load_env_vars()
    model_name = os.getenv("MODEL_NAME", "gpt-4o")

    research_cleaner_agent = create_agent(
        model=model_name,
        tools=[],
        system_prompt=(
            "You clean raw research notes into concise bullet points. "
            "Return a JSON array of 5 to 8 short strings. "
            "No markdown, no headings, no commentary."
        ),
    )

    keyword_agent = create_agent(
        model=model_name,
        tools=[],
        system_prompt=(
            "You extract concise research keywords/topics from provided text. "
            "Return a JSON array of 8 to 15 short keyword strings. "
            "No markdown, no headings, no commentary."
        ),
    )

    return {
        "research_cleaner_agent": research_cleaner_agent,
        "keyword_agent": keyword_agent,
    }
