"""Gmail SMTP sending utilities."""

from __future__ import annotations

import os
import smtplib
from email.message import EmailMessage

from env_config import load_env_vars


def send_email_smtp(to_email: str, subject: str, body: str) -> tuple[bool, str | None]:
    """
    Send an email using Gmail SMTP with TLS.

    Sends to the exact `to_email` value provided by caller.
    """
    load_env_vars()
    gmail_user = os.getenv("GMAIL_USER", "").strip()
    gmail_app_password = os.getenv("GMAIL_APP_PASSWORD", "").strip()

    if not gmail_user:
        return False, "Missing GMAIL_USER."
    if not gmail_app_password:
        return False, "Missing GMAIL_APP_PASSWORD."
    if not to_email:
        return False, "Missing receiver email."

    try:
        message = EmailMessage()
        message["From"] = gmail_user
        message["To"] = to_email
        message["Subject"] = subject
        message.set_content(body or "")

        with smtplib.SMTP("smtp.gmail.com", 587, timeout=20) as server:
            server.starttls()
            server.login(gmail_user, gmail_app_password)
            server.send_message(message)
        return True, None
    except Exception as exc:
        return False, f"SMTP send failed: {exc}"
