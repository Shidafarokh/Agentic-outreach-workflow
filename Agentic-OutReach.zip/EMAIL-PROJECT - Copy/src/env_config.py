"""Environment loading helpers."""

from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv


def load_env_vars() -> None:
    """
    Load environment variables with fallback order:
    1) .env
    2) .env.example (if .env is missing)
    """
    root = Path(__file__).parent.parent
    env_file = root / ".env"
    env_example_file = root / ".env.example"

    if env_file.exists():
        load_dotenv(env_file)
    elif env_example_file.exists():
        load_dotenv(env_example_file)
