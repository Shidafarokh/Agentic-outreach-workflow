"""Persistent profile storage for Streamlit UI."""

from __future__ import annotations

import json
from pathlib import Path


DATA_DIR = Path(__file__).parent.parent / "data"
PROFILE_FILE = DATA_DIR / "my_profile.json"


def _default_profile() -> dict:
    return {
        "full_name": "",
        "program": "MBAN",
        "university": "Saint Mary's University",
        "goal": "Research Assistantship",
        "interests": [],
        "skills": [],
        "projects": [],
        "custom_project": "",
        "availability": "Flexible",
        "contact_email": "",
        "linkedin_url": "",
    }


def load_profile() -> dict:
    """Load profile from data/my_profile.json; create defaults if missing/corrupt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not PROFILE_FILE.exists():
        default = _default_profile()
        with open(PROFILE_FILE, "w", encoding="utf-8") as f:
            json.dump(default, f, indent=2)
        return default

    try:
        with open(PROFILE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return _default_profile()
    except Exception:
        return _default_profile()

    default = _default_profile()
    default.update(data)
    return default


def save_profile(profile_dict: dict) -> None:
    """Persist profile safely to data/my_profile.json."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    data = _default_profile()
    if isinstance(profile_dict, dict):
        data.update(profile_dict)
    with open(PROFILE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
