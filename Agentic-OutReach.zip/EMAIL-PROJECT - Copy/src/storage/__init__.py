"""JSON storage layer for application data"""
