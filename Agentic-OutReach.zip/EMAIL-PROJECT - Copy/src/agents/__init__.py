"""Multi-agent system using LangGraph"""
