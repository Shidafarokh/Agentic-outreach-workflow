"""JSON tracker module for managing application records."""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional


DATA_DIR = Path(__file__).parent.parent / "data"
APPS_FILE = DATA_DIR / "applications.json"


def _ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _initialize_json_file() -> None:
    _ensure_data_dir()
    if not APPS_FILE.exists():
        with open(APPS_FILE, "w", encoding="utf-8") as f:
            json.dump([], f, indent=2)


def _normalize_record(app: dict) -> dict:
    """
    Backward-compatible defaults for old records.
    Existing keys are preserved; only missing keys are added.
    """
    app.setdefault("id", str(uuid.uuid4()))
    app.setdefault("person_name", "")
    app.setdefault("university_name", "")
    app.setdefault("status", "Draft")
    app.setdefault("created_at", datetime.utcnow().isoformat() + "Z")
    app.setdefault("sent_at", None)
    app.setdefault("tone_choice", "Warm")
    app.setdefault("drafts", [])
    app.setdefault("selected_draft_index", 0)
    app.setdefault("final_email_text", "")
    app.setdefault("last_error", None)
    app.setdefault("research_input", "")
    app.setdefault("research_bullets", [])
    app.setdefault("research_keywords", [])
    app.setdefault("professor_name", "")
    app.setdefault("scholar_profile_url", "")
    app.setdefault("recipient_email", "")
    app.setdefault("smu_profile_url", "")
    app.setdefault("email_source", "")
    return app


def load_all() -> list[dict]:
    """Load all application records from JSON file."""
    try:
        _initialize_json_file()
        with open(APPS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            if not isinstance(data, list):
                print("Warning: applications.json is not a list. Returning empty list.")
                return []
            return [_normalize_record(app) for app in data if isinstance(app, dict)]
    except json.JSONDecodeError as exc:
        print(f"Warning: applications.json is corrupted: {exc}")
        return []
    except Exception as exc:
        print(f"Warning: error loading applications.json: {exc}")
        return []


def save_all(records: list[dict]) -> None:
    """Save all application records to JSON file."""
    try:
        _ensure_data_dir()
        with open(APPS_FILE, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2)
    except Exception as exc:
        print(f"Error: failed to save applications.json: {exc}")
        raise


def add_application(person_name: str, university_name: str, tone_choice: str = "Warm") -> dict:
    """Create and add a new application record."""
    now = datetime.utcnow().isoformat() + "Z"
    new_app = {
        "id": str(uuid.uuid4()),
        "person_name": person_name,
        "university_name": university_name,
        "status": "Draft",
        "created_at": now,
        "sent_at": None,
        "tone_choice": tone_choice,
        "drafts": [],
        "selected_draft_index": 0,
        "final_email_text": "",
        "last_error": None,
        "research_input": "",
        "research_bullets": [],
        "research_keywords": [],
        "professor_name": "",
        "scholar_profile_url": "",
        "recipient_email": "",
        "smu_profile_url": "",
        "email_source": "",
    }
    records = load_all()
    records.append(new_app)
    save_all(records)
    return new_app


def update_application(app_id: str, **fields) -> Optional[dict]:
    """Update an application record with specified fields."""
    allowed_fields = {
        "person_name",
        "university_name",
        "status",
        "sent_at",
        "tone_choice",
        "drafts",
        "selected_draft_index",
        "final_email_text",
        "last_error",
        "research_input",
        "research_bullets",
        "research_keywords",
        "professor_name",
        "scholar_profile_url",
        "recipient_email",
        "smu_profile_url",
        "email_source",
    }
    records = load_all()
    for app in records:
        if app.get("id") == app_id:
            for key, value in fields.items():
                if key in allowed_fields:
                    app[key] = value
            _normalize_record(app)
            save_all(records)
            return app
    return None


def delete_application(app_id: str) -> None:
    """Delete an application record by ID."""
    records = load_all()
    remaining = [app for app in records if app.get("id") != app_id]
    save_all(remaining)


def get_application(app_id: str) -> Optional[dict]:
    """Retrieve a single application record by ID."""
    records = load_all()
    for app in records:
        if app.get("id") == app_id:
            return _normalize_record(app)
    return None
