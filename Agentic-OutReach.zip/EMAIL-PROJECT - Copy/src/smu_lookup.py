"""SMU website lookup helpers for professor profile/email discovery."""

from __future__ import annotations

import re
from html import unescape
from urllib.parse import quote_plus, urljoin

import requests


SMU_DOMAIN = "www.smu.ca"
USER_AGENT = "Mozilla/5.0 (EmailProjectBot/1.0)"


def _safe_get(url: str, timeout: int = 12) -> str:
    try:
        resp = requests.get(url, timeout=timeout, headers={"User-Agent": USER_AGENT})
        if resp.status_code == 200 and "text/html" in resp.headers.get("Content-Type", ""):
            return resp.text
    except Exception:
        return ""
    return ""


def _extract_links(html: str, base_url: str) -> list[str]:
    links = re.findall(r'href=["\']([^"\']+)["\']', html, flags=re.IGNORECASE)
    out: list[str] = []
    for link in links:
        full = urljoin(base_url, unescape(link))
        if SMU_DOMAIN not in full:
            continue
        if "#" in full:
            full = full.split("#", 1)[0]
        if full.endswith((".jpg", ".png", ".pdf", ".doc", ".docx")):
            continue
        out.append(full)
    # preserve order + unique
    seen = set()
    uniq = []
    for x in out:
        if x in seen:
            continue
        seen.add(x)
        uniq.append(x)
    return uniq


def _extract_title(html: str) -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", html, flags=re.IGNORECASE | re.DOTALL)
    if not m:
        return ""
    title = re.sub(r"\s+", " ", unescape(m.group(1))).strip()
    return title


def _extract_mailto_or_smu_email(html: str) -> tuple[str | None, str]:
    m_mailto = re.search(r'mailto:([A-Z0-9._%+\-]+@smu\.ca)', html, flags=re.IGNORECASE)
    if m_mailto:
        return m_mailto.group(1), "mailto"

    m_email = re.search(r"([A-Z0-9._%+\-]+@smu\.ca)", html, flags=re.IGNORECASE)
    if m_email:
        return m_email.group(1), "regex"

    return None, "not_found"


def _name_score(professor_name: str, text: str) -> int:
    text_l = text.lower()
    tokens = [t for t in re.split(r"\s+", professor_name.lower().strip()) if t]
    if not tokens:
        return 0
    score = 0
    for token in tokens:
        if token in text_l:
            score += 1
    return score


def _extract_meta_field(html: str, field_name: str) -> str:
    # lightweight heuristic from nearby labels
    pat = rf"{field_name}\s*[:\-]\s*([^<\n\r]+)"
    m = re.search(pat, html, flags=re.IGNORECASE)
    if not m:
        return ""
    return re.sub(r"\s+", " ", unescape(m.group(1))).strip()


def find_smu_candidates(professor_name: str) -> list[dict]:
    """
    Find likely SMU profile pages and extract emails.

    Returns up to 5 candidates:
      {name, title(optional), department(optional), profile_url, email(optional), email_source}
    """
    q = (professor_name or "").strip()
    if not q:
        return []

    query = quote_plus(q)
    search_urls = [
        f"https://www.smu.ca/search.html?q={query}",
        f"https://www.smu.ca/search/?q={query}",
        f"https://www.smu.ca/?s={query}",
    ]

    candidate_urls: list[str] = []
    for surl in search_urls:
        html = _safe_get(surl)
        if not html:
            continue
        links = _extract_links(html, surl)
        for link in links:
            ll = link.lower()
            if any(x in ll for x in ["faculty", "people", "profile", "department", "academics"]):
                candidate_urls.append(link)
            elif q.split()[0].lower() in ll:
                candidate_urls.append(link)

    # fallback: try directory-like pages where names often appear
    for fallback_url in [
        "https://www.smu.ca/academics/faculty-directory.html",
        "https://www.smu.ca/academics/faculty.html",
    ]:
        html = _safe_get(fallback_url)
        if html and q.lower() in html.lower():
            candidate_urls.extend(_extract_links(html, fallback_url))

    # unique
    seen = set()
    dedup_urls = []
    for u in candidate_urls:
        if u in seen:
            continue
        seen.add(u)
        dedup_urls.append(u)

    scored: list[tuple[int, dict]] = []
    for url in dedup_urls[:30]:
        html = _safe_get(url)
        if not html:
            continue

        title = _extract_title(html)
        email, email_source = _extract_mailto_or_smu_email(html)
        text_for_score = f"{title}\n{url}\n{html[:8000]}"
        score = _name_score(q, text_for_score)
        if email:
            score += 2
        if "faculty" in url.lower() or "profile" in url.lower():
            score += 1

        if score <= 0:
            continue

        name = q
        if title:
            # keep concise name-like part before first separator
            name = re.split(r"[-|]", title)[0].strip() or q

        candidate = {
            "name": name,
            "title": _extract_meta_field(html, "title"),
            "department": _extract_meta_field(html, "department"),
            "profile_url": url,
            "email": email,
            "email_source": email_source,
        }
        scored.append((score, candidate))

    scored.sort(key=lambda x: x[0], reverse=True)
    out = [c for _, c in scored[:5]]

    # final de-dup by profile_url
    final: list[dict] = []
    used_urls = set()
    for c in out:
        u = c["profile_url"]
        if u in used_urls:
            continue
        used_urls.add(u)
        final.append(c)
    return final[:5]
