"""LangChain agents for email generation."""

from langchain.agents import create_agent
import os

from env_config import load_env_vars


def build_email_agents():
    """Build and return LangChain agents used by the graph."""
    load_env_vars()
    model_name = os.getenv("MODEL_NAME", "gpt-4o")

    draft_generator = create_agent(
        model=model_name,
        tools=[],
        system_prompt=(
            "You generate university outreach email drafts. "
            "Return exactly three drafts as a JSON array of strings. "
            "No markdown, no extra keys, no commentary."
        ),
    )

    return {"draft_generator": draft_generator}
