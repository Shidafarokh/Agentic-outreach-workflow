"""Utilities and configuration"""
